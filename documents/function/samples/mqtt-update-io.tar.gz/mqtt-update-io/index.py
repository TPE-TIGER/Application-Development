#!/usr/local/bin/python3
# -*- coding: utf-8 -*-

from thingspro.edge.func_v1 import package
from thingspro.edge.api_v1 import api as tpe
import paho.mqtt.client as mqtt
import json
import traceback

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def _set_variable(provider, device, variable, value):
    api = tpe.TPEApiWrapper("PUT", f"tags/access/{provider}/{device}/{variable}")
    payload = {"dataType": "boolean", "dataValue": value["value"]}
    try:
        resp = api.Request(json.dumps(payload))
        if resp.status_code != 200:
            print(resp.json())
            return
        print(resp.json())
        return resp.json()
    except Exception as e:
        print(traceback.format_exc())
        return ""

def set_variables(client, userdata, device, variables):
    resp = []
    for var in variables:
        resp.append(_set_variable(userdata["provider"], device, var, {"value": variables[var]}))

    #print(resp)
    client.publish(userdata["pubTopic"], payload=json.dumps(resp), qos=0, retain=False)

def set_variable(client, userdata, device, variable, value):
    resp = _set_variable(userdata["provider"], device, variable, value)
    #print(resp)
    client.publish(userdata["pubTopic"], payload=json.dumps(resp), qos=0, retain=False)

# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe(userdata["subTopic"])

# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    print(msg.topic+" "+str(msg.payload))
    token = msg.topic.split("/")
    #print(token)
    if token[0] != "" or len(token) < 4:
        print("invalid topic")
        return
    device = token[3]
    variable = ""
    if len(token) >= 5:
        variable = token[4]
    #print("device: {}, variable: {}".format(device, variable))

    values = json.loads(msg.payload.decode("ascii"))
    if variable == "":
        return set_variables(client, userdata, device, values)

    set_variable(client, userdata, device, variable, values)


if __name__ == "__main__":
    # create function client instance
    config = package.Configuration()
    # print parameters defined in package.json
    userdata = config.parameters()
    print(userdata)
    print("start")

    client = mqtt.Client(userdata=config.parameters())
    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(userdata["host"], userdata["port"], 60)

    # Blocking call that processes network traffic, dispatches callbacks and
    # handles reconnecting.
    # Other loop*() functions are available that give a threaded interface and a
    # manual interface.
    # infinite loop
    client.loop_forever()
